#!/bin/bash

ifconfig